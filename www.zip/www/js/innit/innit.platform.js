/**
 * Platform Abstraction Layer
 *
 *
 *
 * 
 */

angular.module('innit.platform',[]).provider('$innitPlatform',function(){


	





})