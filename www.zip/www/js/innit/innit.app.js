angular.module('innit.app',['ionic','innit.auth'])


.provider('$innitApp',function(){

	var _appConfig = {
		baseUrl : 'http://localhost:1337'
	}



	return {

		$get : function(){
			return {

				config : _appConfig


			}
		},

		setBaseUrl : function(baseUrl){

			_appConfig.baseUrl = baseUrl;

		}

	}


})

.controller('AppController',function($scope){

	console.log('welcome to app')


})

.controller('AppLaunchController',function($scope,$state,$timeout,$innitAuth){

	console.log('launching app...')

	//connect socket

	$innitAuth.getGoogleToken()
	//do some shit

 	




	
})